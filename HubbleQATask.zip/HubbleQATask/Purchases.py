from selenium import webdriver
import time
import os
import pyautogui
from selenium.webdriver.common.action_chains import ActionChains

browser = webdriver.Chrome()

#======================================Normal Login
browser.get('http://automationpractice.com/index.php')
browser.maximize_window()
filename = "Test Result/2. Purchase Products.txt"
os.makedirs(os.path.dirname(filename), exist_ok=True)
f = open(filename, 'w')

f.write("Test Report:\n\n")
f.write("=Purchase the Products=\n")
f.write("1. Navigate to website\n")
time.sleep(5)

SignInButton = browser.find_element_by_xpath('/html/body/div/div[1]/header/div[2]/div/div/nav/div[1]/a').click()
time.sleep(3)
f.write("2. Open to Sign In page\n")

Email = browser.find_element_by_id('email').click()
pyautogui.typewrite('syapykah@gmail.com')
time.sleep(3)
f.write("3. Enter Email\n")

Password = browser.find_element_by_id('passwd').click()
pyautogui.typewrite('123456')
time.sleep(3)
f.write("4. Enter Password\n")

Login = browser.find_element_by_id('SubmitLogin').click()
time.sleep(5)
f.write("5. Able to login and navigate to user profile page\n")

WomenTab = browser.find_element_by_xpath('/html/body/div/div[1]/header/div[3]/div/div/div[6]/ul/li[1]/a').click()
time.sleep(4)
f.write("6. Navigate to Women page\n")

Search = browser.find_element_by_id('search_query_top').click()
pyautogui.typewrite('dress')
pyautogui.press('enter')
time.sleep(5)
f.write("7. Search the product keywords\n")

Product = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[3]/div[2]/ul/li[1]/div/div[1]/div/a[1]').click()
time.sleep(5)
f.write("8. Open to Product details page\n")

Color1 = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[4]/div/div/div/div[4]/form/div/div[2]/div/'
                                    'fieldset[2]/div/ul/li[1]').click()
time.sleep(3)

Color2 = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[4]/div/div/div/div[4]/form/div/div[2]/div/'
                                    'fieldset[2]/div/ul/li[2]').click()
time.sleep(3)

Color3 = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[4]/div/div/div/div[4]/form/div/div[2]/div/'
                                    'fieldset[2]/div/ul/li[3]').click()
time.sleep(3)

Color4 = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[4]/div/div/div/div[4]/form/div/div[2]/div/'
                                    'fieldset[2]/div/ul/li[4]').click()
time.sleep(3)
f.write("9. Select the color\n")

ZoomIn = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[4]/div/div/div/div[2]/div[1]/span[2]/img').click()
time.sleep(3)
f.write("10. Zoom in the product image\n")

CloseButton = browser.find_element_by_xpath('/html/body/div[2]/div/a').click()
time.sleep(3)

AddQuantity = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[4]/div/div/div/div[4]/form/div/div[2]/p[1]/a[2]').click()
time.sleep(3)
f.write("12. Add more quantity of the products\n")

Size = browser.find_element_by_id('group_1').click()
pyautogui.press('L')
time.sleep(3)
f.write("13. Select the product size\n")

Wishlist = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[4]/div/div/div/div[4]/form/div/div[3]/p/a').click()
time.sleep(3)
f.write("14. Add the products in the wishlist\n")

Close = browser.find_element_by_xpath('/html/body/div[2]/div/div/a').click()
time.sleep(3)

AddToCart = browser.find_element_by_id('add_to_cart').click()
time.sleep(3)
f.write("15. Add the products into Cart\n")

Checkout = browser.find_element_by_xpath('/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/a').click()
time.sleep(5)

Checkout1 = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[3]/div/p[2]/a[1]').click()
time.sleep(3)

Message = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[3]/div/form/div/div[3]/textarea').click()
pyautogui.typewrite('Only for testing')

Checkout2 = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[3]/div/form/p/button').click()
time.sleep(4)

cgv = browser.find_element_by_id('cgv').click()
time.sleep(2)

Checkout3 = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[3]/div/div/form/p/button').click()
time.sleep(4)

Pay = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[3]/div/div/div[3]/div[2]/div/p/a').click()
time.sleep(4)

ConfirmButton = browser.find_element_by_xpath('/html/body/div/div[2]/div/div[3]/div/form/p/button').click()
time.sleep(5)
f.write("16. The user successfully purchase the products\n")
browser.close()


