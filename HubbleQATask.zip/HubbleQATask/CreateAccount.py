from selenium import webdriver
import time
import os
import pyautogui

browser = webdriver.Chrome()

#======================================Normal Login
browser.get('http://automationpractice.com/index.php')
browser.maximize_window()
filename = "Test Result/1. Create Account.txt"
os.makedirs(os.path.dirname(filename), exist_ok=True)
f = open(filename, 'w')

f.write("Test Report:\n\n")
f.write("=Create Account Page=\n")
f.write("1. Navigate to website\n")
time.sleep(5)

SignInButton = browser.find_element_by_xpath('/html/body/div/div[1]/header/div[2]/div/div/nav/div[1]/a').click()
time.sleep(3)
f.write("2. Navigate to Login page\n")

EmailCreate = browser.find_element_by_id('email_create').click()
pyautogui.typewrite('syapykah@gmail.com')
time.sleep(3)
f.write("3. Enter the Email\n")

SubmitCreate = browser.find_element_by_id('SubmitCreate').click()
time.sleep(3)
f.write("4. Click Create an account \n")

Title = browser.find_element_by_id('id_gender2').click()
time.sleep(3)
f.write("5. Select the title\n")

FirstName = browser.find_element_by_id('customer_firstname').click()
pyautogui.typewrite('Nurul')
time.sleep(3)
f.write("6. Enter First Name\n")

LastName = browser.find_element_by_id('customer_lastname').click()
pyautogui.typewrite('Syafiqah')
time.sleep(3)
f.write("7. Enter Last Name\n")

Password = browser.find_element_by_id('passwd').click()
pyautogui.typewrite('123456')
time.sleep(3)
f.write("8. Enter Password\n")

Day = browser.find_element_by_id('days').click()
pyautogui.press(['1','2','enter'])
time.sleep(3)

Month = browser.find_element_by_id('months').click()
Months = browser.find_element_by_xpath('//*[@id="months"]/option[9]').click()
time.sleep(3)

Year = browser.find_element_by_id('years').click()
pyautogui.press(['1','9','9','5','enter'])
time.sleep(3)
f.write("9. Select the date of birth\n")

'''FirstnameAdd = browser.find_element_by_id('firstname').click()
pyautogui.typewrite('Nurul')
time.sleep(3)

LastNameAdd = browser.find_element_by_id('lastname').click()
pyautogui.typewrite('Syafiqah')
time.sleep(3)'''

Company = browser.find_element_by_id('company').click()
pyautogui.typewrite('testing.com')
time.sleep(3)
f.write("10. Enter Company\n")

Address1 = browser.find_element_by_id('address1').click()
pyautogui.typewrite('Only for testing')
time.sleep(3)
f.write("11. Enter Address\n")

Address2 = browser.find_element_by_id('address2').click()
pyautogui.typewrite('Only for testing')
time.sleep(3)
f.write("12. Enter Address 2\n")

City = browser.find_element_by_id('city').click()
pyautogui.typewrite('Kajang')
time.sleep(3)
f.write("13. Enter City\n")

State = browser.find_element_by_id('id_state').click()
pyautogui.press(['H','enter'])
time.sleep(3)
f.write("14. Select State\n")

Postcode = browser.find_element_by_id('postcode').click()
pyautogui.typewrite('43000')
time.sleep(3)
f.write("15. Enter Postcode\n")

Country = browser.find_element_by_id('id_country').click()
pyautogui.press(['down','enter'])
time.sleep(3)
f.write("16. Select Country\n")

Information = browser.find_element_by_id('other').click()
pyautogui.typewrite('Only for testing')
time.sleep(3)
f.write("17. Enter Other Information\n")

Phone = browser.find_element_by_id('phone_mobile').click()
pyautogui.typewrite('0109122923')
time.sleep(3)
f.write("18. Enter Phone Number\n")

SubmitAcc = browser.find_element_by_id('submitAccount').click()
time.sleep(5)
f.write("19. Click Submit account and the account created\n")